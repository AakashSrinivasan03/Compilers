package visitor;
import java.util.*;

public class Temp_1
{ public String reg="";
  public String temp_name="";
  public int reg_num=-1;
  public int location_stk;
  public int start;
  public int end=-1;
  public int spill_temp=0;

}
 class Expression
{
	public String reg="";
	public int reg_num;
	public String code="";


} 

 class Fn
{ public String fn_name="";
  public String no_args;
  public String max_call_args="100";
  public String max_alloc="100";
  public String code="";
  public int spilt=0;
  public Vector<Temp_1> temp_vars=new Vector();
  public int search_temp(String s1)
  { for(int i=0;i<temp_vars.size();i++)
  	 { if( s1.equals(temp_vars.get(i).temp_name))
  	 	{  System.out.println("LLLLLLLLLLLLL");
  	 		return i;


  	 	}

  	 }
  	 return -1;


  }
  public void update_liveness(String s1,int pos)
  { 
  	 if(search_temp(s1)==-1)
  	 { Temp_1 tmp=new Temp_1();
  	 	tmp.temp_name=s1;
  	 	tmp.start=pos;
  	 	temp_vars.add(tmp);




  	 }
  	 else
  	 { int idx=search_temp(s1);
  	 	if(pos>temp_vars.get(idx).end)
  	 	{ temp_vars.get(idx).end=pos;

  	 	}




  	 }





  }

public void sort_asc()
{

  for(int i=0;i<temp_vars.size();i++)
  {
    for(int j=0;j<temp_vars.size()-i-1;j++)
    { if(temp_vars.get(j).start>temp_vars.get(j+1).start)
    	{ Temp_1 tmp=new Temp_1();
    		tmp=temp_vars.get(j);
    		temp_vars.set(j,temp_vars.get(j+1));
    		temp_vars.set(j+1,tmp);


    	}




    }



  }





}


public void linearscan()
{  System.out.println(temp_vars.size());
	Vector<Temp_1> reg_allocated=new Vector();
	int pos_on_stk=0;
	Vector<Integer> free_reg=new Vector();
	for(int i=0;i<18;i++)
		free_reg.add(i);

  for(int i=0;i<temp_vars.size();i++)
  {  
  	 for(int j=0;j<reg_allocated.size();j++)
  	 { if(reg_allocated.get(j).end<=temp_vars.get(i).start)
  	 	{   int tmp=reg_allocated.get(j).reg_num;
  	 		reg_allocated.removeElement(reg_allocated.get(j));
  	 		free_reg.add(tmp);
  	 	}


  	 }

  	 if(reg_allocated.size()<18)
  	 {
  	 	Temp_1 tmp=new Temp_1();
  	 	tmp=temp_vars.get(i);
  	 	tmp.reg_num=free_reg.get(0);
  	 	System.out.println("PPP");
  	 	free_reg.removeElement(free_reg.get(0));
  	 	reg_allocated.add(tmp);

  	 }
  	 else
  	 {  spilt=1;
  	 	Temp_1 max=new Temp_1();
  	 	max=reg_allocated.get(0);
  	 	 for(int j=0;j<reg_allocated.size();j++)
  	 { if(reg_allocated.get(j).end>=max.start)
  	 	{  max=reg_allocated.get(j);

  	 	}



  	 }
  	 int idx=-1;
  	 //for(int ii=0;ii<reg_allocated.size();ii++)
  	 //	if(reg_allocated.get(ii)==temp_vars.get(i))
  	 //		break;
  	 if(max.end>temp_vars.get(i).end)
  	 { max.spill_temp=1;
  	 	max.location_stk=pos_on_stk++;
  	 	temp_vars.get(i).reg=max.reg;


  	 }
  	 else
  	 { temp_vars.get(i).spill_temp=1;
  	 	temp_vars.get(i).location_stk=pos_on_stk++;
  	 	//reg_allocated.get(i).reg=max.reg;


  	 }



  	 }









  }

System.out.println("==============================");
for(int i=0;i<temp_vars.size();i++)
{  System.out.println(temp_vars.get(i).temp_name+Integer.toString(temp_vars.get(i).reg_num));
  

}








}

















}


