package visitor;
import java.util.*;

public class Temp_1
{ public String reg="";
  public String temp_name="";
  public int reg_num=-1;
  public int location_stk;
  public int start;
  public int end=-1;
  public int spill_temp=0;
  public int is_temp_under_4=0;
  public int is_temp_arg_spl=0;

}
 class Expression
{
	public String reg="";
	public int reg_num;
	public String code="";


} 
class Statement
{//public Set<Temp_1> temp_set=new Set();
	public Set def = new LinkedHashSet();
	public Set use = new LinkedHashSet();
	public Set in = new LinkedHashSet();
	public Set out = new LinkedHashSet();
	public String target_label=null;
	public int is_uncond_jump=0;
	public Vector<Statement> succ=new Vector();
	public int line_number;
	public String stmt_code="";

}

 class Fn
{ public String fn_name="";
  public String no_args;
  public String max_call_args="100";
  public String max_alloc="100";
  public String code="";
  public int spilt=0;
  public Vector<Temp_1> temp_vars=new Vector();
  public Vector<Temp_1> temp_vars_reg_alloc=new Vector();
  public Vector<Statement> fn_statements=new Vector();

  public void cfg()
  { int flag=1;
  	int counter=0;
  	 while(flag==1)
  	 {  flag=0;
  	 	counter++;
  	 	for(int i=0;i<fn_statements.size();i++)
  	 	{  Set in_dash = new LinkedHashSet(fn_statements.get(i).in);
  	 		 Set out_dash = new LinkedHashSet(fn_statements.get(i).out);
  	 		//in_dash=fn_statements.get(i).in
  	 		fn_statements.get(i).out = new LinkedHashSet();
  	 		for(int k=0;k<fn_statements.get(i).succ.size();k++)
  	 		{//Set out_dash = new LinkedHashSet();
  	 		 fn_statements.get(i).out.addAll(fn_statements.get(i).succ.get(k).in);
  	 		}
  	 		 //fn_statements.get(i).out=out_dash;
  	 		  Set in_temp = new LinkedHashSet();
  	 		 in_temp.addAll(fn_statements.get(i).use);
  	 		 Set diff = new LinkedHashSet(fn_statements.get(i).out);
			 diff.removeAll(fn_statements.get(i).def);
			 in_temp.addAll(diff);
			 fn_statements.get(i).in=in_temp;
			 if(!in_dash.equals(fn_statements.get(i).in) || !out_dash.equals(fn_statements.get(i).out))
			  {flag=1;}	

  	 		

  	 	}



  	 }
  	 System.out.println("##########################################");
  	 System.out.println(counter);
  	 //temp_vars=new Vector();
  	 for(int i=0;i<fn_statements.size();i++)
  	 {
  	 	Iterator iter = fn_statements.get(i).in.iterator(); 
      
   // check values
   while (iter.hasNext()){
   //System.out.println("Value: "+iter.next() + " ");  
   String tmp=(String)iter.next();
   //if(tmp.equals("TEMP200"))
   //	System.out.println("\n======\n=========\n*******");
    String[] parts = tmp.split("P");
    int idx=Integer.valueOf(parts[1]);
    int no_args_val=Integer.valueOf(no_args);
    if(idx>=no_args_val)
   update_liveness_1(tmp,fn_statements.get(i).line_number,0,-1);
else if(idx<4)
{   if(search_temp_1(tmp)==-1)
	{Temp_1 tmp_1=new Temp_1();
  	 	//System.out.println("#########YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY");
  	 	tmp_1.temp_name=tmp;
  	 	tmp_1.start=0;
  	 	//String[] parts = tmp.split("P");
  	 	tmp_1.reg_num=18+idx;
  	 	tmp_1.is_temp_under_4=1;
  	 	temp_vars_reg_alloc.add(tmp_1);
	}

}

else
{  int stk_pos=idx- no_args_val;
	update_liveness_1(tmp,fn_statements.get(i).line_number,1,stk_pos);

}


   }



  	 }

  	 //for(int i=0;temp_vars.size();i++)




  	 linearscan();







  }









  public void print1()
  { for(int i=0;i<fn_statements.size();i++)
  	{  System.out.println("USE:");
  		System.out.println(fn_statements.get(i).use);
  		System.out.println("DEF:");
  		System.out.println(fn_statements.get(i).def);
  		System.out.println("IN:");
  		System.out.println(fn_statements.get(i).in);
  		System.out.println("OUT:");
  		System.out.println(fn_statements.get(i).out);
  		System.out.println("============================");

  	}


  }




  public int search_temp(String s1)
  { for(int i=0;i<temp_vars.size();i++)
  	 { if( s1.equals(temp_vars.get(i).temp_name))
  	 	{  //System.out.println("LLLLLLLLLLLLL");
  	 		return i;


  	 	}

  	 }
  	 return -1;


  }
  public int search_temp_1(String s1)
  { for(int i=0;i<temp_vars_reg_alloc.size();i++)
  	 { if( s1.equals(temp_vars_reg_alloc.get(i).temp_name))
  	 	{  //System.out.println("LLLLLLLLLLLLL");
  	 		return i;


  	 	}

  	 }
  	 return -1;


  }
  public void update_liveness(String s1,int pos)
  { 
  	 if(search_temp(s1)==-1)
  	 { Temp_1 tmp=new Temp_1();
  	 	tmp.temp_name=s1;
  	 	tmp.start=pos;
  	 	temp_vars.add(tmp);




  	 }
  	 else
  	 { int idx=search_temp(s1);
  	 	if(pos>temp_vars.get(idx).end)
  	 	{ temp_vars.get(idx).end=pos;

  	 	}




  	 }





  }
   public void update_liveness_1(String s1,int pos,int flag,int stk_pos)
  { 
  	 if(search_temp_1(s1)==-1)
  	 { Temp_1 tmp=new Temp_1();
  	 	tmp.temp_name=s1;
  	 	tmp.start=pos;
  	 	tmp.end=pos;
  	 	if(flag==1)
  	 	{ tmp.location_stk=stk_pos;
  	 		tmp.is_temp_arg_spl=1;

  	 	}
  	 	temp_vars_reg_alloc.add(tmp);




  	 }
  	 else
  	 { int idx=search_temp_1(s1);
  	 	if(pos>temp_vars_reg_alloc.get(idx).end)
  	 	{ temp_vars_reg_alloc.get(idx).end=pos;

  	 	}




  	 }





  }

public void sort_asc()
{

  for(int i=0;i<temp_vars_reg_alloc.size();i++)
  {
    for(int j=0;j<temp_vars_reg_alloc.size()-i-1;j++)
    { if(temp_vars_reg_alloc.get(j).start>temp_vars_reg_alloc.get(j+1).start)
    	{ Temp_1 tmp=new Temp_1();
    		tmp=temp_vars_reg_alloc.get(j);
    		temp_vars_reg_alloc.set(j,temp_vars_reg_alloc.get(j+1));
    		temp_vars_reg_alloc.set(j+1,tmp);


    	}




    }



  }





}


public void linearscan()
{  System.out.println("LINEAR SCAN.........");
	System.out.println(temp_vars_reg_alloc.size());
	Vector<Temp_1> reg_allocated=new Vector();
	int pos_on_stk=0;
	Vector<Integer> free_reg=new Vector();
	for(int i=0;i<18;i++)
		free_reg.add(i);

  for(int i=0;i<temp_vars_reg_alloc.size();i++)
  {  
  	 for(int j=0;j<reg_allocated.size();j++)
  	 { if(reg_allocated.get(j).end<temp_vars_reg_alloc.get(i).start)
  	 	{   int tmp=reg_allocated.get(j).reg_num;
  	 		reg_allocated.removeElement(reg_allocated.get(j));
  	 		free_reg.add(tmp);
  	 	}


  	 }
  	 if(temp_vars_reg_alloc.get(i).is_temp_under_4!=1)
  	 {if(reg_allocated.size()<18)
  	 {
  	 	Temp_1 tmp=new Temp_1();
  	 	tmp=temp_vars_reg_alloc.get(i);
  	 	tmp.reg_num=free_reg.get(0);
  	 	System.out.println("PPP");
  	 	free_reg.removeElement(free_reg.get(0));
  	 	reg_allocated.add(tmp);

  	 }
  	 else
  	 {  spilt=1;
  	 	Temp_1 max=new Temp_1();
  	 	max=reg_allocated.get(0);
  	 	 for(int j=0;j<reg_allocated.size();j++)
  	 { if(reg_allocated.get(j).end>=max.start)
  	 	{  max=reg_allocated.get(j);

  	 	}



  	 }
  	 int idx=-1;
  	 //for(int ii=0;ii<reg_allocated.size();ii++)
  	 //	if(reg_allocated.get(ii)==temp_vars.get(i))
  	 //		break;
  	 if(max.end>temp_vars_reg_alloc.get(i).end)
  	 { max.spill_temp=1;
  	 	if(max.is_temp_arg_spl!=1)
  	 	max.location_stk=pos_on_stk++;
  	 	temp_vars_reg_alloc.get(i).reg=max.reg;


  	 }
  	 else
  	 { temp_vars_reg_alloc.get(i).spill_temp=1;
  	 	if(temp_vars_reg_alloc.get(i).is_temp_arg_spl!=1)
  	 	temp_vars_reg_alloc.get(i).location_stk=pos_on_stk++;
  	 	//reg_allocated.get(i).reg=max.reg;


  	 }



  	 }
  	}









  }

System.out.println("==============================");
for(int i=0;i<temp_vars_reg_alloc.size();i++)
{  System.out.println(temp_vars_reg_alloc.get(i).temp_name+Integer.toString(temp_vars_reg_alloc.get(i).reg_num));
  

}
System.out.println("spilt="+Integer.toString(spilt));








}

















}


