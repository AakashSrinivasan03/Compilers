import java.util.*;

import javafx.util.Pair;
import syntaxtree.*;
import visitor.*;

public class P5 {
   public static void main(String [] args) {
      try {
         Node root = new microIRParser(System.in).Goal();
         //System.out.println("Program parsed successfully");
         HashMap<String, Integer > X = (HashMap<String, Integer >) root.accept(new GJDepthFirst2(),null);
         Object T=root.accept(new GJDepthFirst(),X);
         root.accept(new GJDepthFirst3(),T);
      }
      catch (ParseException e) {
         System.out.println(e.toString());
      }
      
   }
}


